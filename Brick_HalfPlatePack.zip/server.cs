datablock fxDTSBrickData(brick2x2fHalfPlateData)
{
	brickFile = "./2x2fHalfPlate.blb";
	category = "Plates";
	subCategory = "Half-plates";
	uiName = "2x2F Vertical Half-Plate";
	iconName = "Add-Ons/Brick_HalfPlatePack/2x2fHalfPlate";
};

datablock fxDTSBrickData(brick1x2x2fHalfPlateData)
{
	brickFile = "./1x2x2fHalfPlate.blb";
	category = "Plates";
	subCategory = "Half-plates";
	uiName = "1x2F Half-Plate";
	iconName = "Add-Ons/Brick_HalfPlatePack/1x2x2fHalfPlate";
};

datablock fxDTSBrickData(brick1f_2x2fHalfPlateData)
{
	brickFile = "./1f_2x2fHalfPlate.blb";
	category = "Plates";
	subCategory = "Half-plates";
	uiName = "1F 1x2F Half-Plate";
	iconName = "Add-Ons/Brick_HalfPlatePack/1f_2x2fHalfPlate";
};

datablock fxDTSBrickData(brick1f_2x2fHalfPlate_PrintData)
{
	brickFile = "./1f_2x2fHalfPlate_Print.blb";
	category = "Plates";
	subCategory = "Half-plates";
	uiName = "1F 1x2F Half-Plate Print";
	iconName = "Add-Ons/Brick_HalfPlatePack/1f_2x2fHalfPlate_Print";

	hasPrint = 1;
	printAspectRatio = "1x1f";
};