datablock fxDTSBrickData(brick1x2fVerticalPrintData)
{
	brickFile = "./1x2fVerticalPrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick2x2fVerticalPrintData)
{
	brickFile = "./2x2fVerticalPrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "2x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/2x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1fVerticalPrintEdgeData)
{
	brickFile = "./1x1fVerticalPrintEdge.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x1F Vertical Edge Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1fVerticalPrintEdge";

	hasPrint = 1;
	printAspectRatio = "2x2f";

};

datablock fxDTSBrickData(brick1x2x2fVerticalPrintData)
{
	brickFile = "./1x2x2fVerticalPrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x 2x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x2x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1f_2x2fVerticalPrintData)
{
	brickFile = "./1f_2x2fVerticalPrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1F 2x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1f_2x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick2x2fVerticalDoublePrintData)
{
	brickFile = "./2x2fVerticalDoublePrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "2x2F Vertical Double Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/2x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1fVerticalPrintCornerData)
{
	brickFile = "./1x1fVerticalPrintCorner.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x1F Vertical Corner Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1fVerticalPrintCorner";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1x2fVerticalPrintData)
{
	brickFile = "./1x1x2fVerticalPrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x 1x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1f_1x2fVerticalPrintData)
{
	brickFile = "./1f_1x2fVerticalPrint.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1F 1x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1f_1x2fVerticalPrint";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1x1fVerticalPrintEdgeData)
{
	brickFile = "./1x1x1fVerticalPrintEdge.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x 1x1F Vertical Edge Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1x1fVerticalPrintEdge";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1f_1x1fVerticalPrintEdgeData)
{
	brickFile = "./1f_1x1fVerticalPrintEdge.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1F 1x1F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1f_1x1fVerticalPrintEdge";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1x1fVerticalPrintCornerData)
{
	brickFile = "./1x1x1fVerticalPrintCorner.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1x 1x1F Vertical Corner Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1x1fVerticalPrintCorner";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1f_1x1fVerticalPrintCornerData)
{
	brickFile = "./1f_1x1fVerticalPrintCorner.blb";
	category = "Plates";
	subCategory = "Prints";
	uiName = "1F 1x1F Vertical Corner Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1f_1x1fVerticalPrintCorner";

	hasPrint = 1;
	printAspectRatio = "2x2f";
};
//vert nocollide

datablock fxDTSBrickData(brick1x2fVerticalPrintNocollideData)
{
	brickFile = "./1x2fVerticalPrint.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 1x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x2fVerticalPrintNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick2x2fVerticalPrintNocollideData)
{
	brickFile = "./2x2fVerticalPrint.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 2x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/2x2fVerticalPrintNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1fVerticalPrintEdgeNocollideData)
{
	brickFile = "./1x1fVerticalPrintEdge.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 1x1F Vertical Edge Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1fVerticalPrintEdgeNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";

};

datablock fxDTSBrickData(brick1x2x2fVerticalPrintNocollideData)
{
	brickFile = "./1x2x2fVerticalPrint.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 1x 2x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x2x2fVerticalPrintNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1f_2x2fVerticalPrintNocollideData)
{
	brickFile = "./1f_2x2fVerticalPrint.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 1F 2x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1f_2x2fVerticalPrintNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick2x2fVerticalDoublePrintNocollideData)
{
	brickFile = "./2x2fVerticalDoublePrint.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 2x2F Vertical Double Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/2x2fVerticalPrintNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1fVerticalPrintCornerNocollideData)
{
	brickFile = "./1x1fVerticalPrintCorner.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 1x1F Vertical Corner Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1fVerticalPrintCornerNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1x2fVerticalPrintNocollideData)
{
	brickFile = "./1x1x2fVerticalPrint.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 1x 1x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1x2fVerticalPrintNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1f_1x2fVerticalPrintNocollideData)
{
	brickFile = "./1f_1x2fVerticalPrint.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 1F 1x2F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1f_1x2fVerticalPrintNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1x1fVerticalPrintEdgeNocollideData)
{
	brickFile = "./1x1x1fVerticalPrintEdge.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 1x 1x1F Vertical Edge Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1x1fVerticalPrintEdgeNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1f_1x1fVerticalPrintEdgeNocollideData)
{
	brickFile = "./1f_1x1fVerticalPrintEdge.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 1F 1x1F Vertical Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1f_1x1fVerticalPrintEdgeNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1x1x1fVerticalPrintNocollideData)
{
	brickFile = "./1x1x1fVerticalPrintCorner.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 1x 1x1F Vertical Corner Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1x1x1fVerticalPrintCornerNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";
};

datablock fxDTSBrickData(brick1f_1x1fVerticalPrintNocollideData)
{
	brickFile = "./1f_1x1fVerticalPrintCorner.blb";
	category = "No-Collide";
	subCategory = "Prints";
	uiName = "[N] 1F 1x1F Vertical Corner Print";
	iconName = "Add-Ons/Brick_VerticalPlatePack/1f_1x1fVerticalPrintCornerNO";
	isWaterBrick = true;

	hasPrint = 1;
	printAspectRatio = "2x2f";
};