datablock ParticleData(ShrinkingLargeSquareParticle)
{
	textureName		= "Base/Data/Shapes/White";
	dragCoefficient		= 0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0;
	windCoefficient		= 0;
	constantAcceleration	= 0;
	lifetimeMS		= 900;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 0;
	spinRandomMin		= 0;
	spinRandomMax		= 0;
	useInvAlpha		= false;

	colors[0]		= "1 1 1 1";
	colors[1]		= "1 1 1 1";

	sizes[0]		= 0.9;
	sizes[1]		= 0;

	times[0]		= 0;
	times[1]		= 1;
};
datablock ParticleEmitterData(ShrinkingLargeSquareEmitter)
{
	ejectionPeriodMS	= 30;
	periodVarianceMS	= 0;
	ejectionVelocity	= 5;
	ejectionOffset		= 0;
	velocityVariance	= 0;
	thetaMin		= 0;
	thetaMax		= 0;
	phiReferenceVel		= 0;
	phiVariance		= 360;
	overrideAdvance		= false;

	particles		= ShrinkingLargeSquareParticle;
	useEmitterColors	= true;

	uiName			= "Square - Shrinking - Large";
};
datablock ParticleData(ShrinkingMediumSquareParticle)
{
	textureName		= "Base/Data/Shapes/White";
	dragCoefficient		= 0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0;
	windCoefficient		= 0;
	constantAcceleration	= 0;
	lifetimeMS		= 900;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 0;
	spinRandomMin		= 0;
	spinRandomMax		= 0;
	useInvAlpha		= false;

	colors[0]		= "1 1 1 1";
	colors[1]		= "1 1 1 1";

	sizes[0]		= 0.6;
	sizes[1]		= 0;

	times[0]		= 0;
	times[1]		= 1;
};
datablock ParticleEmitterData(ShrinkingMediumSquareEmitter)
{
	ejectionPeriodMS	= 30;
	periodVarianceMS	= 0;
	ejectionVelocity	= 5;
	ejectionOffset		= 0;
	velocityVariance	= 0;
	thetaMin		= 0;
	thetaMax		= 0;
	phiReferenceVel		= 0;
	phiVariance		= 360;
	overrideAdvance		= false;

	particles		= ShrinkingMediumSquareParticle;
	useEmitterColors	= true;

	uiName			= "Square - Shrinking - Medium";
};
datablock ParticleData(ShrinkingSmallSquareParticle)
{
	textureName		= "Base/Data/Shapes/White";
	dragCoefficient		= 0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0;
	windCoefficient		= 0;
	constantAcceleration	= 0;
	lifetimeMS		= 900;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 0;
	spinRandomMin		= 0;
	spinRandomMax		= 0;
	useInvAlpha		= false;

	colors[0]		= "1 1 1 1";
	colors[1]		= "1 1 1 1";

	sizes[0]		= 0.3;
	sizes[1]		= 0;

	times[0]		= 0;
	times[1]		= 1;
};
datablock ParticleEmitterData(ShrinkingSmallSquareEmitter)
{
	ejectionPeriodMS	= 30;
	periodVarianceMS	= 0;
	ejectionVelocity	= 5;
	ejectionOffset		= 0;
	velocityVariance	= 0;
	thetaMin		= 0;
	thetaMax		= 0;
	phiReferenceVel		= 0;
	phiVariance		= 360;
	overrideAdvance		= false;

	particles		= ShrinkingSmallSquareParticle;
	useEmitterColors	= true;

	uiName			= "Square - Shrinking - Small";
};
datablock ParticleData(GrowingLargeSquareParticle)
{
	textureName		= "Base/Data/Shapes/White";
	dragCoefficient		= 0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0;
	windCoefficient		= 0;
	constantAcceleration	= 0;
	lifetimeMS		= 900;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 0;
	spinRandomMin		= 0;
	spinRandomMax		= 0;
	useInvAlpha		= false;

	colors[0]		= "1 1 1 1";
	colors[1]		= "1 1 1 1";

	sizes[0]		= 0.9;
	sizes[1]		= 1;

	times[0]		= 0;
	times[1]		= 1;
};
datablock ParticleEmitterData(GrowingLargeSquareEmitter)
{
	ejectionPeriodMS	= 30;
	periodVarianceMS	= 0;
	ejectionVelocity	= 5;
	ejectionOffset		= 0;
	velocityVariance	= 0;
	thetaMin		= 0;
	thetaMax		= 0;
	phiReferenceVel		= 0;
	phiVariance		= 360;
	overrideAdvance		= false;

	particles		= GrowingLargeSquareParticle;
	useEmitterColors	= true;

	uiName			= "Square - Growing - Large";
};
datablock ParticleData(GrowingMediumSquareParticle)
{
	textureName		= "Base/Data/Shapes/White";
	dragCoefficient		= 0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0;
	windCoefficient		= 0;
	constantAcceleration	= 0;
	lifetimeMS		= 900;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 0;
	spinRandomMin		= 0;
	spinRandomMax		= 0;
	useInvAlpha		= false;

	colors[0]		= "1 1 1 1";
	colors[1]		= "1 1 1 1";

	sizes[0]		= 0;
	sizes[1]		= 0.6;

	times[0]		= 0;
	times[1]		= 1;
};
datablock ParticleEmitterData(GrowingMediumSquareEmitter)
{
	ejectionPeriodMS	= 30;
	periodVarianceMS	= 0;
	ejectionVelocity	= 5;
	ejectionOffset		= 0;
	velocityVariance	= 0;
	thetaMin		= 0;
	thetaMax		= 0;
	phiReferenceVel		= 0;
	phiVariance		= 360;
	overrideAdvance		= false;

	particles		= GrowingMediumSquareParticle;
	useEmitterColors	= true;

	uiName			= "Square - Growing - Medium";
};
datablock ParticleData(GrowingSmallSquareParticle)
{
	textureName		= "Base/Data/Shapes/White";
	dragCoefficient		= 0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0;
	windCoefficient		= 0;
	constantAcceleration	= 0;
	lifetimeMS		= 900;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 0;
	spinRandomMin		= 0;
	spinRandomMax		= 0;
	useInvAlpha		= false;

	colors[0]		= "1 1 1 1";
	colors[1]		= "1 1 1 1";

	sizes[0]		= 0;
	sizes[1]		= 0.3;

	times[0]		= 0;
	times[1]		= 1;
};
datablock ParticleEmitterData(GrowingSmallSquareEmitter)
{
	ejectionPeriodMS	= 30;
	periodVarianceMS	= 0;
	ejectionVelocity	= 5;
	ejectionOffset		= 0;
	velocityVariance	= 0;
	thetaMin		= 0;
	thetaMax		= 0;
	phiReferenceVel		= 0;
	phiVariance		= 360;
	overrideAdvance		= false;

	particles		= GrowingSmallSquareParticle;
	useEmitterColors	= true;

	uiName			= "Square - Growing - Small";
};
datablock ParticleData(BasicLargeSquareParticle)
{
	textureName		= "Base/Data/Shapes/White";
	dragCoefficient		= 0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0;
	windCoefficient		= 0;
	constantAcceleration	= 0;
	lifetimeMS		= 900;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 0;
	spinRandomMin		= 0;
	spinRandomMax		= 0;
	useInvAlpha		= false;

	colors[0]		= "1 1 1 1";
	colors[1]		= "1 1 1 1";

	sizes[0]		= 0.9;
	sizes[1]		= 0.9;

	times[0]		= 0;
	times[1]		= 1;
};
datablock ParticleEmitterData(BasicLargeSquareEmitter)
{
	ejectionPeriodMS	= 30;
	periodVarianceMS	= 0;
	ejectionVelocity	= 5;
	ejectionOffset		= 0;
	velocityVariance	= 0;
	thetaMin		= 0;
	thetaMax		= 0;
	phiReferenceVel		= 0;
	phiVariance		= 360;
	overrideAdvance		= false;

	particles		= BasicLargeSquareParticle;
	useEmitterColors	= true;

	uiName			= "Square - Basic - Large";
};
datablock ParticleData(BasicMediumSquareParticle)
{
	textureName		= "Base/Data/Shapes/White";
	dragCoefficient		= 0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0;
	windCoefficient		= 0;
	constantAcceleration	= 0;
	lifetimeMS		= 900;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 0;
	spinRandomMin		= 0;
	spinRandomMax		= 0;
	useInvAlpha		= false;

	colors[0]		= "1 1 1 1";
	colors[1]		= "1 1 1 1";

	sizes[0]		= 0.6;
	sizes[1]		= 0.6;

	times[0]		= 0;
	times[1]		= 1;
};
datablock ParticleEmitterData(BasicMediumSquareEmitter)
{
	ejectionPeriodMS	= 30;
	periodVarianceMS	= 0;
	ejectionVelocity	= 5;
	ejectionOffset		= 0;
	velocityVariance	= 0;
	thetaMin		= 0;
	thetaMax		= 0;
	phiReferenceVel		= 0;
	phiVariance		= 360;
	overrideAdvance		= false;

	particles		= BasicMediumSquareParticle;
	useEmitterColors	= true;

	uiName			= "Square - Basic - Medium";
};
datablock ParticleData(BasicSmallSquareParticle)
{
	textureName		= "Base/Data/Shapes/White";
	dragCoefficient		= 0;
	gravityCoefficient	= 0;
	inheritedVelFactor	= 0;
	windCoefficient		= 0;
	constantAcceleration	= 0;
	lifetimeMS		= 900;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 0;
	spinRandomMin		= 0;
	spinRandomMax		= 0;
	useInvAlpha		= false;

	colors[0]		= "1 1 1 1";
	colors[1]		= "1 1 1 1";

	sizes[0]		= 0.3;
	sizes[1]		= 0.3;

	times[0]		= 0;
	times[1]		= 1;
};
datablock ParticleEmitterData(BasicSmallSquareEmitter)
{
	ejectionPeriodMS	= 30;
	periodVarianceMS	= 0;
	ejectionVelocity	= 5;
	ejectionOffset		= 0;
	velocityVariance	= 0;
	thetaMin		= 0;
	thetaMax		= 0;
	phiReferenceVel		= 0;
	phiVariance		= 360;
	overrideAdvance		= false;

	particles		= BasicSmallSquareParticle;
	useEmitterColors	= true;

	uiName			= "Square - Basic - Small";
};