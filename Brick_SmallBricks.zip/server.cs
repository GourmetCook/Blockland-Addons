datablock fxDTSBrickData(brick05x2PlateData)
{
	brickFile = "./0.5x2.blb";
	category = "Plates";
	subCategory = "0.5x";
	uiName = "0.5x2";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x2";
};

datablock fxDTSBrickData(brick05x2fPlateData)
{
	brickFile = "./0.5x2f.blb";
	category = "Plates";
	subCategory = "0.5x";
	uiName = "0.5x2F";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x2f";
};

datablock fxDTSBrickData(brick05x1PlateData)
{
	brickFile = "./0.5x1.blb";
	category = "Plates";
	subCategory = "0.5x";
	uiName = "0.5x1";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x1";
};

datablock fxDTSBrickData(brick05x1fPlateData)
{
	brickFile = "./0.5x1f.blb";
	category = "Plates";
	subCategory = "0.5x";
	uiName = "0.5x1F";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x1f";
};

datablock fxDTSBrickData(brick05x05EdgeData)
{
	brickFile = "./0.5x0.5Edge.blb";
	category = "Plates";
	subCategory = "0.5x";
	uiName = "0.5x0.5 Edge";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x0.5Edge";
};

datablock fxDTSBrickData(brick05x05fEdgeData)
{
	brickFile = "./0.5x0.5fEdge.blb";
	category = "Plates";
	subCategory = "0.5x";
	uiName = "0.5x0.5F";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x0.5fEdge";
};

datablock fxDTSBrickData(brick05x05CornerData)
{
	brickFile = "./0.5x0.5Corner.blb";
	category = "Plates";
	subCategory = "0.5x";
	uiName = "0.5x0.5 Corner";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x0.5Corner";
};

datablock fxDTSBrickData(brick05x05fCornerData)
{
	brickFile = "./0.5x0.5fCorner.blb";
	category = "Plates";
	subCategory = "0.5x";
	uiName = "0.5x0.5F Corner";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x0.5fCorner";
};










datablock fxDTSBrickData(brick025x2PlateData)
{
	brickFile = "./0.25x2.blb";
	category = "Plates";
	subCategory = "0.25x";
	uiName = "0.25x2";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x2";
};

datablock fxDTSBrickData(brick025x2fPlateData)
{
	brickFile = "./0.25x2f.blb";
	category = "Plates";
	subCategory = "0.25x";
	uiName = "0.25x2F";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x2f";
};

datablock fxDTSBrickData(brick025x1PlateData)
{
	brickFile = "./0.25x1.blb";
	category = "Plates";
	subCategory = "0.25x";
	uiName = "0.25x1";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x1";
};

datablock fxDTSBrickData(brick025x1fPlateData)
{
	brickFile = "./0.25x1f.blb";
	category = "Plates";
	subCategory = "0.25x";
	uiName = "0.25x1F";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x1f";
};

datablock fxDTSBrickData(brick025x025EdgeData)
{
	brickFile = "./0.25x0.25Edge.blb";
	category = "Plates";
	subCategory = "0.25x";
	uiName = "0.25x0.25 Edge";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x0.25Edge";
};

datablock fxDTSBrickData(brick025x025fEdgeData)
{
	brickFile = "./0.25x0.25fEdge.blb";
	category = "Plates";
	subCategory = "0.25x";
	uiName = "0.25x0.25F";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x0.25fEdge";
};

datablock fxDTSBrickData(brick025x025CornerData)
{
	brickFile = "./0.25x0.25Corner.blb";
	category = "Plates";
	subCategory = "0.25x";
	uiName = "0.25x0.25 Corner";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x0.25Corner";
};

datablock fxDTSBrickData(brick025x025fCornerData)
{
	brickFile = "./0.25x0.25fCorner.blb";
	category = "Plates";
	subCategory = "0.25x";
	uiName = "0.25x0.25F Corner";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x0.25fCorner";
};










datablock fxDTSBrickData(brick075x2PlateData)
{
	brickFile = "./0.75x2.blb";
	category = "Plates";
	subCategory = "0.75x";
	uiName = "0.75x2";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x2";
};

datablock fxDTSBrickData(brick075x2fPlateData)
{
	brickFile = "./0.75x2f.blb";
	category = "Plates";
	subCategory = "0.75x";
	uiName = "0.75x2F";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x2f";
};

datablock fxDTSBrickData(brick075x1PlateData)
{
	brickFile = "./0.75x1.blb";
	category = "Plates";
	subCategory = "0.75x";
	uiName = "0.75x1";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x1";
};

datablock fxDTSBrickData(brick075x1fPlateData)
{
	brickFile = "./0.75x1f.blb";
	category = "Plates";
	subCategory = "0.75x";
	uiName = "0.75x1F";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x1f";
};

datablock fxDTSBrickData(brick075x075EdgeData)
{
	brickFile = "./0.75x0.75Edge.blb";
	category = "Plates";
	subCategory = "0.75x";
	uiName = "0.75x0.75 Edge";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x0.75Edge";
};

datablock fxDTSBrickData(brick075x075fEdgeData)
{
	brickFile = "./0.75x0.75fEdge.blb";
	category = "Plates";
	subCategory = "0.75x";
	uiName = "0.75x0.75F";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x0.75fEdge";
};

datablock fxDTSBrickData(brick075x075CornerData)
{
	brickFile = "./0.75x0.75Corner.blb";
	category = "Plates";
	subCategory = "0.75x";
	uiName = "0.75x0.75 Corner";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x0.75Corner";
};

datablock fxDTSBrickData(brick075x075fCornerData)
{
	brickFile = "./0.75x0.75fCorner.blb";
	category = "Plates";
	subCategory = "0.75x";
	uiName = "0.75x0.75F Corner";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x0.75fCorner";
};


//noCOLLIDES


datablock fxDTSBrickData(brick05x2PlateNOData)
{
	brickFile = "./0.5x2.blb";
	category = "No-collide";
	subCategory = "0.5x";
	uiName = "[N] 0.5x2";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x2NO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x2fPlateNOData)
{
	brickFile = "./0.5x2f.blb";
	category = "No-collide";
	subCategory = "0.5x";
	uiName = "[N] 0.5x2F";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x2fNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x1PlateNOData)
{
	brickFile = "./0.5x1.blb";
	category = "No-collide";
	subCategory = "0.5x";
	uiName = "[N] 0.5x1";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x1NO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x1fPlateNOData)
{
	brickFile = "./0.5x1f.blb";
	category = "No-collide";
	subCategory = "0.5x";
	uiName = "[N] 0.5x1F";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x1fNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x05EdgeNOData)
{
	brickFile = "./0.5x0.5Edge.blb";
	category = "No-collide";
	subCategory = "0.5x";
	uiName = "[N] 0.5x0.5 Edge";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x0.5EdgeNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x05fEdgeNOData)
{
	brickFile = "./0.5x0.5fEdge.blb";
	category = "No-collide";
	subCategory = "0.5x";
	uiName = "[N] 0.5x0.5F";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x0.5fEdgeNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x05CornerNOData)
{
	brickFile = "./0.5x0.5Corner.blb";
	category = "No-collide";
	subCategory = "0.5x";
	uiName = "[N] 0.5x0.5 Corner";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x0.5CornerNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x05fCornerNOData)
{
	brickFile = "./0.5x0.5fCorner.blb";
	category = "No-collide";
	subCategory = "0.5x";
	uiName = "[N] 0.5x0.5F Corner";
	iconName = "Add-Ons/Brick_SmallBricks/0.5x0.5fCornerNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x2PlateNOData)
{
	brickFile = "./0.25x2.blb";
	category = "No-collide";
	subCategory = "0.25x";
	uiName = "[N] 0.25x2";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x2NO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x2fPlateNOData)
{
	brickFile = "./0.25x2f.blb";
	category = "No-collide";
	subCategory = "0.25x";
	uiName = "[N] 0.25x2F";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x2fNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x1PlateNOData)
{
	brickFile = "./0.25x1.blb";
	category = "No-collide";
	subCategory = "0.25x";
	uiName = "[N] 0.25x1";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x1NO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x1fPlateNOData)
{
	brickFile = "./0.25x1f.blb";
	category = "No-collide";
	subCategory = "0.25x";
	uiName = "[N] 0.25x1F";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x1fNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x025EdgeNOData)
{
	brickFile = "./0.25x0.25Edge.blb";
	category = "No-collide";
	subCategory = "0.25x";
	uiName = "[N] 0.25x0.25 Edge";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x0.25EdgeNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x025fEdgeNOData)
{
	brickFile = "./0.25x0.25fEdge.blb";
	category = "No-collide";
	subCategory = "0.25x";
	uiName = "[N] 0.25x0.25F";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x0.25fEdgeNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x025CornerNOData)
{
	brickFile = "./0.25x0.25Corner.blb";
	category = "No-collide";
	subCategory = "0.25x";
	uiName = "[N] 0.25x0.25 Corner";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x0.25CornerNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x025fCornerNOData)
{
	brickFile = "./0.25x0.25fCorner.blb";
	category = "No-collide";
	subCategory = "0.25x";
	uiName = "[N] 0.25x0.25F Corner";
	iconName = "Add-Ons/Brick_SmallBricks/0.25x0.25fCornerNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x2PlateNOData)
{
	brickFile = "./0.75x2.blb";
	category = "No-collide";
	subCategory = "0.75x";
	uiName = "[N] 0.75x2";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x2NO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x2fPlateNOData)
{
	brickFile = "./0.75x2f.blb";
	category = "No-collide";
	subCategory = "0.75x";
	uiName = "[N] 0.75x2F";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x2fNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x1PlateNOData)
{
	brickFile = "./0.75x1.blb";
	category = "No-collide";
	subCategory = "0.75x";
	uiName = "[N] 0.75x1";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x1NO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x1fPlateNOData)
{
	brickFile = "./0.75x1f.blb";
	category = "No-collide";
	subCategory = "0.75x";
	uiName = "[N] 0.75x1F";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x1fNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x075EdgeNOData)
{
	brickFile = "./0.75x0.75Edge.blb";
	category = "No-collide";
	subCategory = "0.75x";
	uiName = "[N] 0.75x0.75 Edge";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x0.75EdgeNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x075fEdgeNOData)
{
	brickFile = "./0.75x0.75fEdge.blb";
	category = "No-collide";
	subCategory = "0.75x";
	uiName = "[N] 0.75x0.75F";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x0.75fEdgeNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x075CornerNOData)
{
	brickFile = "./0.75x0.75Corner.blb";
	category = "No-collide";
	subCategory = "0.75x";
	uiName = "[N] 0.75x0.75 Corner";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x0.75CornerNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x075fCornerNOData)
{
	brickFile = "./0.75x0.75fCorner.blb";
	category = "No-collide";
	subCategory = "0.75x";
	uiName = "[N] 0.75x0.75F Corner";
	iconName = "Add-Ons/Brick_SmallBricks/0.75x0.75fCornerNO";
	isWaterBrick = true;
};