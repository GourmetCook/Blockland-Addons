datablock fxDTSBrickData (brick1x1PlateRampData)
{
	brickFile = "./1x1.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "1x1 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/1x1";
	orientationFix = 1;
	collisionShapeName = "./1x1.dts";
	};
	
datablock fxDTSBrickData (brick1x2PlateRampData)
{
	brickFile = "./1x2.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "1x2 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/1x2";
	orientationFix = 1;
	collisionShapeName = "./1x2.dts";
	};
	
datablock fxDTSBrickData (brick1x3PlateRampData)
{
	brickFile = "./1x3.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "1x3 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/1x3";
	orientationFix = 1;
	collisionShapeName = "./1x3.dts";
	};
	
datablock fxDTSBrickData (brick1x4PlateRampData)
{
	brickFile = "./1x4.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "1x4 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/1x4";
	orientationFix = 1;
	collisionShapeName = "./1x4.dts";
	};
	
datablock fxDTSBrickData (brick1x6PlateRampData)
{
	brickFile = "./1x6.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "1x6 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/1x6";
	orientationFix = 1;
	collisionShapeName = "./1x6.dts";
	};
	
datablock fxDTSBrickData (brick1x8PlateRampData)
{
	brickFile = "./1x8.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "1x8 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/1x8";
	orientationFix = 1;
	collisionShapeName = "./1x8.dts";
	};
	
//2

datablock fxDTSBrickData (brick2x1PlateRampData)
{
	brickFile = "./2x1.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "2x1 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/2x1";
	orientationFix = 1;
	collisionShapeName = "./2x1.dts";
	};

datablock fxDTSBrickData (brick2x2PlateRampData)
{
	brickFile = "./2x2.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "2x2 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/2x2";
	orientationFix = 1;
	collisionShapeName = "./2x2.dts";
	};
	
datablock fxDTSBrickData (brick2x3PlateRampData)
{
	brickFile = "./2x3.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "2x3 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/2x3";
	orientationFix = 1;
	collisionShapeName = "./2x3.dts";
	};
	
datablock fxDTSBrickData (brick2x4PlateRampData)
{
	brickFile = "./2x4.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "2x4 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/2x4";
	orientationFix = 1;
	collisionShapeName = "./2x4.dts";
	};
	
datablock fxDTSBrickData (brick2x6PlateRampData)
{
	brickFile = "./2x6.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "2x6 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/2x6";
	orientationFix = 1;
	collisionShapeName = "./2x6.dts";
	};

datablock fxDTSBrickData (brick2x8PlateRampData)
{
	brickFile = "./2x8.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "2x8 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/2x8";
	orientationFix = 1;
	collisionShapeName = "./2x8.dts";
	};

//4	
	
datablock fxDTSBrickData (brick4x1PlateRampData)
{
	brickFile = "./4x1.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "4x1 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/4x1";
	orientationFix = 1;
	collisionShapeName = "./4x1.dts";
	};
	
datablock fxDTSBrickData (brick4x2PlateRampData)
{
	brickFile = "./4x2.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "4x2 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/4x2";
	orientationFix = 1;
	collisionShapeName = "./4x2.dts";
	};
	
datablock fxDTSBrickData (brick4x3PlateRampData)
{
	brickFile = "./4x3.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "4x3 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/4x3";
	orientationFix = 1;
	collisionShapeName = "./4x3.dts";
	};
	
datablock fxDTSBrickData (brick4x4PlateRampData)
{
	brickFile = "./4x4.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "4x4 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/4x4";
	orientationFix = 1;
	collisionShapeName = "./4x4.dts";
	};
	
datablock fxDTSBrickData (brick4x6PlateRampData)
{
	brickFile = "./4x6.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "4x6 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/4x6";
	orientationFix = 1;
	collisionShapeName = "./4x6.dts";
	};
	
datablock fxDTSBrickData (brick4x8PlateRampData)
{
	brickFile = "./4x8.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "4x8 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/4x8";
	orientationFix = 1;
	collisionShapeName = "./4x8.dts";
	};
	
//6

datablock fxDTSBrickData (brick6x1PlateRampData)
{
	brickFile = "./6x1.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "6x1 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/6x1";
	orientationFix = 1;
	collisionShapeName = "./6x1.dts";
	};
	
datablock fxDTSBrickData (brick6x2PlateRampData)
{
	brickFile = "./6x2.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "6x2 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/6x2";
	orientationFix = 1;
	collisionShapeName = "./6x2.dts";
	};
	
datablock fxDTSBrickData (brick6x3PlateRampData)
{
	brickFile = "./6x3.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "6x3 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/6x3";
	orientationFix = 1;
	collisionShapeName = "./6x3.dts";
	};
	
datablock fxDTSBrickData (brick6x4PlateRampData)
{
	brickFile = "./6x4.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "6x4 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/6x4";
	orientationFix = 1;
	collisionShapeName = "./6x4.dts";
	};
	
datablock fxDTSBrickData (brick6x6PlateRampData)
{
	brickFile = "./6x6.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "6x6 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/6x6";
	orientationFix = 1;
	collisionShapeName = "./6x6.dts";
	};
	
datablock fxDTSBrickData (brick6x8PlateRampData)
{
	brickFile = "./6x8.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "6x8 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/6x8";
	orientationFix = 1;
	collisionShapeName = "./6x8.dts";
	};

//8
	
datablock fxDTSBrickData (brick8x1PlateRampData)
{
	brickFile = "./8x1.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "8x1 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/8x1";
	orientationFix = 1;
	collisionShapeName = "./8x1.dts";
	};
	
datablock fxDTSBrickData (brick8x2PlateRampData)
{
	brickFile = "./8x2.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "8x2 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/8x2";
	orientationFix = 1;
	collisionShapeName = "./8x2.dts";
	};
	
datablock fxDTSBrickData (brick8x3PlateRampData)
{
	brickFile = "./8x3.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "8x3 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/8x3";
	orientationFix = 1;
	collisionShapeName = "./8x3.dts";
	};
	
datablock fxDTSBrickData (brick8x4PlateRampData)
{
	brickFile = "./8x4.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "8x4 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/8x4";
	orientationFix = 1;
	collisionShapeName = "./8x4.dts";
	};
	
datablock fxDTSBrickData (brick8x6PlateRampData)
{
	brickFile = "./8x6.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "8x6 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/8x6";
	orientationFix = 1;
	collisionShapeName = "./8x6.dts";
	};
	
datablock fxDTSBrickData (brick8x8PlateRampData)
{
	brickFile = "./8x8.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Plate Ramps";
	uiName = "8x8 Plate Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/8x8";
	orientationFix = 1;
	collisionShapeName = "./8x8.dts";
	};	
	
//halfbricks

datablock fxDTSBrickData (brick1x1HalfbrickRampData)
{
	brickFile = "./1x1h.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Halfbrick Ramps";
	uiName = "1x1h Halfbrick Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/1x1h";
	orientationFix = 1;
	collisionShapeName = "./1x1h.dts";
	};
	
datablock fxDTSBrickData (brick2x1HalfbrickRampData)
{
	brickFile = "./2x1h.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Halfbrick Ramps";
	uiName = "2x1h Halfbrick Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/2x1h";
	orientationFix = 1;
	collisionShapeName = "./2x1h.dts";
	};
	
datablock fxDTSBrickData (brick4x1HalfbrickRampData)
{
	brickFile = "./4x1h.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Halfbrick Ramps";
	uiName = "4x1h Halfbrick Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/4x1h";
	orientationFix = 1;
	collisionShapeName = "./4x1h.dts";
	};
	
datablock fxDTSBrickData (brick6x1HalfbrickRampData)
{
	brickFile = "./6x1h.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Halfbrick Ramps";
	uiName = "6x1h Halfbrick Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/6x1h";
	orientationFix = 1;
	collisionShapeName = "./6x1h.dts";
	};
	
datablock fxDTSBrickData (brick8x1HalfbrickRampData)
{
	brickFile = "./8x1h.blb";
	canCover = true;
	category = "Ramps";
	subCategory = "Halfbrick Ramps";
	uiName = "8x1h Halfbrick Ramp";
	iconName = "Add-Ons/Brick_PlateHighRamps/8x1h";
	orientationFix = 1;
	collisionShapeName = "./8x1h.dts";
	};