//Fire
datablock ParticleData(sFireExplosionParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.5;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 500;
	textureName          = "Add-Ons/Projectile_Pong/Square.png";
	spinSpeed		= 0.0;
	spinRandomMin		= -0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "1 0.5 0 1";
	colors[1]     = "1 0 0 1";
	sizes[0]      = 0.5;
	sizes[1]      = 0.0;
};

datablock ParticleEmitterData(sFireExplosionEmitter)
{
   ejectionPeriodMS = 80;
   periodVarianceMS = 0;
   ejectionVelocity = 3;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 35;
   phiReferenceVel  = 0;
   phiVariance      = 35;
   overrideAdvance = false;
   particles = "sFireExplosionParticle";

   useEmitterColors = false;

   uiName = "Square Fire";
};

//Smoke
datablock ParticleData(sSmokeExplosionParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 1.0;
	constantAcceleration = 0.5;
	lifetimeMS           = 7000;
	lifetimeVarianceMS   = 3000;
	textureName          = "Add-Ons/Projectile_Pong/Square.png";
	spinSpeed		= 0.0;
	spinRandomMin		= -0.0;
	spinRandomMax		= 0.0;
	colors[0]     = "0.3 0.3 0.3 1";
	colors[1]     = "0.2 0.2 0.2 1";
	sizes[0]      = 1.0;
	sizes[1]      = 0.0;
};

datablock ParticleEmitterData(sSmokeExplosionEmitter)
{
   ejectionPeriodMS = 300;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 35;
   phiReferenceVel  = 0;
   phiVariance      = 35;
   overrideAdvance = false;
   particles = "sSmokeExplosionParticle";

   useEmitterColors = true;

   uiName = "Square Smoke";
};
//Water
datablock ParticleData(sWaterExplosionParticle)
{
	dragCoefficient      = 0.0;
	gravityCoefficient   = 0.0;
	inheritedVelFactor   = 0.0;
	constantAcceleration = 0.2;
	lifetimeMS           = 1000;
	lifetimeVarianceMS   = 500;
	textureName          = "Add-Ons/Projectile_Pong/Square.png";
	spinSpeed		= 0.0;
	spinRandomMin		= -0.0;
	spinRandomMax		= 0.0;
	colors[0]     = ".2 1 1 1";
	colors[1]     = "0 0 1 1";
	sizes[0]      = 0.5;
	sizes[1]      = 0.0;
};

datablock ParticleEmitterData(sWaterExplosionEmitter)
{
   ejectionPeriodMS = 150;
   periodVarianceMS = 0;
   ejectionVelocity = -3;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 0; //Amount of "wind"
   phiReferenceVel  = 0;
   phiVariance      = 35;
   overrideAdvance = false;
   particles = "sWaterExplosionParticle";

   useEmitterColors = false;

   uiName = "Square Water";
};