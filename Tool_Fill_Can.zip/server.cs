//Fill Can by Zor

// Change $Pref::Server::FillCan_MaxBricks in-game in the console, example:
//   $Pref::Server::FillCan_MaxBricks = 600;

if($Pref::Server::FillCan_MaxBricks$="")
 $Pref::Server::FillCan_MaxBricks=500;

function paintfill(%client,%obj,%newcolor){
 %oldcolor=%obj.getcolorid();
 if(%client.isAdmin || %client.isSuperAdmin)
  %limit=128000;
 else
  %limit=$pref::server::fillcan_maxbricks;
 %fillcount=0;
 %list=new scriptobject(){count=0; oldcolor=%oldcolor; newcolor=%newcolor;};
 missioncleanup.add(%list);
 %list.obj[-1+%list.count++]=%obj;
 %obj.fill=1;
 for(%x=0;%x<%list.count;%x++){
  %obj=%list.obj[%x];
  %obj.setcolor(%newcolor);
  %fillcount++;
  if(%fillcount>=%limit){
   messageclient(%client,'MsgPlantError_Limit');
   centerprint(%client,"\c3Reached Fill Can Brick Limit ("@$pref::server::fillcan_maxbricks@")",2,3);
   break;
  }
  %data=%obj.getdatablock();
  %rot=round(getword(%obj.rotation,3));
  if(%rot==90 || %rot==270){
   %sizex=%data.bricksizey;
   %sizey=%data.bricksizex;
  }else{
   %sizex=%data.bricksizex;
   %sizey=%data.bricksizey;
  }
  %sizez=%data.bricksizez;
  %box=(%sizex*0.5+0.6) SPC (%sizey*0.5+0.6) SPC (%sizez*0.2+0.3);
  InitContainerBoxSearch(%obj.getposition(),%box,$typemasks::fxbrickobjecttype);
  while(%target=containerSearchNext()){
   if(%target.isplanted() && %target.getcolorid()==%oldcolor){
    if(gettrustlevel(%client,%target)>=2){
     if(!%target.fill){
      %target.fill=1;
      %list.obj[-1+%list.count++]=%target;
     }
    }
   }
  }
 }
 for(%x=0;%x<%list.count;%x++)
  %list.obj[%x].fill=0;
 %client.undostack.push(%list TAB "FILLPAINT");
}

function paintFXfill(%client,%obj,%newfx){
 %oldcolor=%obj.getcolorid();
 if(%client.isAdmin || %client.isSuperAdmin)
  %limit=128000;
 else
  %limit=$pref::server::fillcan_maxbricks;
 %fillcount=0;
 %list=new scriptobject(){count=0; oldcolor=%oldcolor; newfx=%newfx;};
 missioncleanup.add(%list);
 %list.obj[-1+%list.count++]=%obj;
 %obj.fill=1;
 for(%x=0;%x<%list.count;%x++){
  %obj=%list.obj[%x];
  if(%obj.getcolorfxid())
   %list.oldfx[%x]=%obj.getcolorfxid();
  %obj.setcolorfx(%newfx);
  %fillcount++;
  if(%fillcount>=%limit){
   messageclient(%client,'MsgPlantError_Limit');
   centerprint(%client,"\c3Reached Fill Can Brick Limit ("@$pref::server::fillcan_maxbricks@")",2,3);
   break;
  }
  %data=%obj.getdatablock();
  %rot=round(getword(%obj.rotation,3));
  if(%rot==90 || %rot==270){
   %sizex=%data.bricksizey;
   %sizey=%data.bricksizex;
  }else{
   %sizex=%data.bricksizex;
   %sizey=%data.bricksizey;
  }
  %sizez=%data.bricksizez;
  %box=(%sizex*0.5+0.6) SPC (%sizey*0.5+0.6) SPC (%sizez*0.2+0.3);
  InitContainerBoxSearch(%obj.getposition(),%box,$typemasks::fxbrickobjecttype);
  while(%target=containerSearchNext()){
   if(%target.isplanted() && %target.getcolorid()==%oldcolor){
    if(gettrustlevel(%client,%target)>=2){
     if(!%target.fill){
      %target.fill=1;
      %list.obj[-1+%list.count++]=%target;
     }
    }
   }
  }
 }
 for(%x=0;%x<%list.count;%x++)
  %list.obj[%x].fill=0;
 %client.undostack.push(%list TAB "FILLPAINT");
}

function shapeFXfill(%client,%obj,%newfx){
 %oldcolor=%obj.getcolorid();
 if(%client.isAdmin || %client.isSuperAdmin)
  %limit=128000;
 else
  %limit=$pref::server::fillcan_maxbricks;
 %fillcount=0;
 %list=new scriptobject(){count=0; oldcolor=%oldcolor; newfx=%newfx+7;};
 missioncleanup.add(%list);
 %list.obj[-1+%list.count++]=%obj;
 %obj.fill=1;
 for(%x=0;%x<%list.count;%x++){
  %obj=%list.obj[%x];
  if(%obj.getshapefxid())
   %list.oldfx[%x]=%obj.getshapefxid();
  %obj.setshapefx(%newfx);
  %fillcount++;
  if(%fillcount>=%limit){
   messageclient(%client,'MsgPlantError_Limit');
   centerprint(%client,"\c3Reached Fill Can Brick Limit ("@$pref::server::fillcan_maxbricks@")",2,3);
   break;
  }
  %data=%obj.getdatablock();
  %rot=round(getword(%obj.rotation,3));
  if(%rot==90 || %rot==270){
   %sizex=%data.bricksizey;
   %sizey=%data.bricksizex;
  }else{
   %sizex=%data.bricksizex;
   %sizey=%data.bricksizey;
  }
  %sizez=%data.bricksizez;
  %box=(%sizex*0.5+0.6) SPC (%sizey*0.5+0.6) SPC (%sizez*0.2+0.3);
  InitContainerBoxSearch(%obj.getposition(),%box,$typemasks::fxbrickobjecttype);
  while(%target=containerSearchNext()){
   if(%target.isplanted() && %target.getcolorid()==%oldcolor){
    if(gettrustlevel(%client,%target)>=2){
     if(!%target.fill){
      %target.fill=1;
      %list.obj[-1+%list.count++]=%target;
     }
    }
   }
  }
 }
 for(%x=0;%x<%list.count;%x++)
  %list.obj[%x].fill=0;
 %client.undostack.push(%list TAB "FILLPAINT");
}

datablock ParticleData(fillcanTrailParticle)
{
	dragCoefficient		= 3.0;
	windCoefficient		= 0.0;
	gravityCoefficient	= 0.0;
	inheritedVelFactor	= 0.0;
	constantAcceleration	= 0.0;
	lifetimeMS		= 420;
	lifetimeVarianceMS	= 0;
	spinSpeed		= 0.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	useInvAlpha		= false;
	animateTexture		= false;
	//framesPerSec		= 1;

	textureName		= "base/data/particles/star1";
	//animTexName		= "~/data/particles/dot";

	// Interpolation variables
	colors[0]	= "0.7 0.7 1 0.2";
	colors[1]	= "0.4 0.4 1 0.1";
	sizes[0]	= 0.4;
	sizes[1]	= 0.01;
	times[0]	= 0.0;
	times[1]	= 1.0;
};

datablock ParticleEmitterData(fillcanTrailEmitter)
{
   ejectionPeriodMS = 2;
   periodVarianceMS = 0;

   ejectionVelocity = 20;
   velocityVariance = 0;

   ejectionOffset = 0;

   thetaMin         = 0.0;
   thetaMax         = 0.0;  

   phiReferenceVel = 0;
   phiVariance = 360;

   particles = fillcanTrailParticle;
};

//effects
datablock ParticleData(fillcanExplosionParticle)
{
	dragCoefficient      = 5;
	gravityCoefficient   = 0.1;
	inheritedVelFactor   = 0.2;
	constantAcceleration = -0.1;
	lifetimeMS           = 700;
	lifetimeVarianceMS   = 300;
	textureName          = "base/data/particles/dot";
	spinSpeed		= 0.0;
	spinRandomMin		= -50.0;
	spinRandomMax		= 50.0;
	colors[0]     = "0.6 0.6 0.9 0.9";
	colors[1]     = "0.6 0.6 0.6 0.0";
	sizes[0]      = 0.25;
	sizes[1]      = 0.0;
};

datablock ParticleEmitterData(fillcanExplosionEmitter)
{
   ejectionPeriodMS = 7;
   periodVarianceMS = 0;
   ejectionVelocity = 5;
   velocityVariance = 1.0;
   ejectionOffset   = 0.0;
   thetaMin         = 0;
   thetaMax         = 90;
   phiReferenceVel  = 0;
   phiVariance      = 360;
   overrideAdvance = false;
   particles = "fillcanExplosionParticle";
};

datablock ExplosionData(fillcanExplosion)
{
   //explosionShape = "";
//	soundProfile = 0;

   lifeTimeMS = 150;

   particleEmitter = fillcanExplosionEmitter;
   particleDensity = 10;
   particleRadius = 0.2;

   faceViewer     = true;
   explosionScale = "1 1 1";

   shakeCamera = false;
   camShakeFreq = "10.0 11.0 10.0";
   camShakeAmp = "1.0 1.0 1.0";
   camShakeDuration = 0.5;
   camShakeRadius = 10.0;

   // Dynamic light
   lightStartRadius = 0;
   lightEndRadius = 2;
   lightStartColor = "0.6 0.6 0.9";
   lightEndColor = "0 0 0";
};


//projectile
datablock ProjectileData(fillcanProjectile)
{
   //projectileShapeName = "./shapes/arrow.dts";

   directDamage        = 0;
   directDamageType    = $DamageType::ArrowDirect;

   radiusDamage        = 0;
   damageRadius        = 0;
   radiusDamageType    = $DamageType::ArrowDirect;

   explosion           = fillcanExplosion;
//   particleEmitter     = fillcanTrailEmitter;

   muzzleVelocity      = 20;
   velInheritFactor    = 0;

   armingDelay         = 0;
   lifetime            = 500;
   fadeDelay           = 250;
   bounceElasticity    = 0;
   bounceFriction      = 0;
   isBallistic         = false;
   gravityMod = 0.0;

   hasLight    = false;
   lightRadius = 3.0;
   lightColor  = "0 0 0.5";
};


//////////
// item //
//////////
datablock ItemData(fillcanItem)
{
	category = "Weapon";  // Mission editor category
	className = "Weapon"; // For inventory system

	 // Basic Item Properties
	shapeFile = "base/data/shapes/spraycan.dts";
	rotate = false;
	mass = 1;
	density = 0.2;
	elasticity = 0.2;
	friction = 0.6;
	emap = true;

	//gui stuff
	uiName = "Fill Can";
	iconName = "./icon_fillcan";
	doColorShift = true;
	colorShiftColor = "0.85 0.85 1 1";

	 // Dynamic properties defined by the scripts
	image = fillcanImage;
	canDrop = true;
};

datablock ShapeBaseImageData(fillcanImage : rainbowSprayCanImage)
{
   // Basic Item properties
   shapeFile = "base/data/shapes/spraycan.dts";

   // Specify mount point & offset for 3rd person, and eye offset
   // for first person rendering.
   mountPoint = 0;
   offset = "0 0 0";
   eyeOffset = "0.7 1 -0.6";
   rotation = eulerToMatrix( "0 0 10" );

   // Projectile && Ammo.
   item = fillcanItem;
   ammo = " ";
   projectile = fillcanProjectile;
   projectileType = Projectile;
   minShotTime = 700;

   doColorShift = true;
   colorShiftColor = fillcanItem.colorShiftColor;

   stateTransitionOnNoAmmo[1]       = "NoAmmo";

   stateTimeoutValue[2] = 0.7;
   stateEmitter[2] = fillcanTrailEmitter;

   stateName[5]   = "NoAmmo";
   stateScript[5]="onNoAmmo";
   stateTransitionOnAmmo[5] = "Ready";
};

function fillcanprojectile::oncollision(%this,%obj,%col,%fade,%pos,%normal){
 %client=%obj.client;
 if(!isobject(%client))
  return;
 if(%col.getclassname()$=fxdtsbrick){
  if(isobject(%client.minigame)){
   if(!%client.minigame.enablepainting){
    centerprint(%client,"\c5Painting is currently disabled.",3,3);
    return;
   }
  }
  if(gettrustlevel(%obj.client,%col)>=2){
    if(%client.currentFXcan){
     if(%client.currentFXcan>7)
      shapeFXfill(%obj.client,%col,%obj.client.currentFXcan-8);
     else
      paintFXfill(%obj.client,%col,%obj.client.currentFXcan-1);
    }else if(%col.getcolorid()!=%obj.client.currentcolor)
     paintfill(%obj.client,%col,%obj.client.currentcolor);
  }else{
   %name=%col.getgroup().name;
   centerprint(%client,%name@" does not trust you enough to do that.",3,3);
  }
 }else if(%col.getclassname()$=player){
  if(%client.currentfxcan){
   %rand=getrandom(0,$randFacecount-1);
   cancel(%col.faceresetsched);
   %col.faceresetsched=schedule(2500,0,resetface,%col);
   %col.setfacename($randFace[%rand]);
   if(%col.client.accent==1)
    %col.setnodecolor("visor",getwords(%col.client.accentcolor,0,2) SPC "0.7");
  }else{
   %color=getcoloridtable(%obj.client.currentcolor);
   %col.settempcolor(%color,2500);
//   if(getword(%color,3)==1)
//    %col.emote(hateimage);
  }
 }else if(%col.getclassname()$=wheeledvehicle || %col.getclassname()$=flyingvehicle){
  if(gettrustlevel(%client,%col.spawnbrick)>=2){
   if(%client.currentfxcan){
     %client.undostack.push(%col TAB "COLORGENERIC" TAB %col.color);
     %recolor=0;
     if(%col.spawnbrick.recolorvehicle){
      %col.spawnbrick.recolorvehicle=0;
      %recolor=1;
     }
     %col.color=(getrandom(0,100)/100) SPC (getrandom(0,100)/100) SPC (getrandom(0,100)/100) SPC "1";
     %col.spawnbrick.colorvehicle();
     if(%recolor)
      %col.spawnbrick.recolorvehicle=1;
   }else{
    if(%col.spawnbrick.recolorvehicle){
     %col.spawnbrick.setcolor(%client.currentcolor);
     %col.color=getcoloridtable(%client.currentcolor);
     %col.spawnbrick.colorvehicle();
     %client.undostack.push(%col.spawnbrick TAB "COLOR" TAB %col.spawnbrick.getcolorid());
     for(%x=0;%x<%col.getmountedobjectcount();%x++)
       %col.getmountedobject(%x).settempcolor(%col.color,2500);
    }else{
     %col.color=setword(getcoloridtable(%client.currentcolor),3,1);
     %col.spawnbrick.colorvehicle();
     %client.undostack.push(%col TAB "COLORGENERIC" TAB %col.color);
     for(%x=0;%x<%col.getmountedobjectcount();%x++)
       %col.getmountedobject(%x).settempcolor(%col.color,2500);
    }
   }
  }else
   centerprint(%client,%col.spawnbrick.getgroup().name@" does not trust you enough to do that.",3,3);
 }
}

$randFace0="smiley";
$randFace1="asciiTerror";
$randFace2="memeBlockMongler";
$randFace3="memeCats";
$randFace4="memeDesu";
$randFace5="memeGrinMan";
$randFace6="memeHappy";
$randFace7="memePBear";
$randFace8="memeYaranika";
$randFace9="smileyBlonde";
$randFace10="smileyCreepy";
$randFace11="smileyEvil1";
$randFace12="smileyEvil2";
$randFace13="smileyFemale1";
$randFace14="smileyOld";
$randFace15="smileyPirate1";
$randFace16="smileyPirate2";
$randFace17="smileyPirate3";
$randFace18="smileyRedBeard";
$randFace19="smileyRedBeard2";
$randFacecount=20;

function resetface(%obj){
 if(!isobject(%obj))
  return;
 %obj.setfacename(%obj.client.facename);
 if(%obj.client.accent==1)
  %obj.setnodecolor("visor",%obj.client.accentcolor);
}

function servercmdfillcan(%client){
 if(isobject(%client.minigame)){
  if(!%client.minigame.enablepainting){
   centerprint(%client,"\c5Painting is currently disabled.",3,3);
   return;
  }
 }
 %client.player.updatearm(fillcanimage);
 %client.player.mountimage(fillcanimage,0);
}

package fillcan{
 function servercmdundobrick(%client){
  %str=%client.undostack.val[%client.undostack.head-1];
  if(getfield(%str,1)$="FILLPAINT"){
   %list=getfield(%str,0);
   if(%list.newfx$=""){ //undoing normal paint fill
    for(%x=%list.count-1;%x>-1;%x--){
     %b=%list.obj[%x];
     if(isobject(%b)){
      if(%b.getcolorid()==%list.newcolor)
       %b.setcolor(%list.oldcolor);
     }
    }
   }else{ //undoing fx paint fill
    if(%list.newfx>6){ // *shape fx*
     %list.newfx-=7;
     for(%x=%list.count-1;%x>-1;%x--){
      %b=%list.obj[%x];
      if(isobject(%b)){
       if(%b.getshapefxid()==%list.newfx)
        %b.setshapefx(%list.oldfx[%x]);
      }
     }
    }else{ // *color fx*
     for(%x=%list.count-1;%x>-1;%x--){
      %b=%list.obj[%x];
      if(isobject(%b)){
       if(%b.getcolorfxid()==%list.newfx)
        %b.setcolorfx(%list.oldfx[%x]);
      }
     }
    }
   }
   %client.undostack.pop();
   %list.delete();
   %client.player.playthread(0,undo);
  }else
   parent::servercmdundobrick(%client);
 }

 function servercmdusefxcan(%client,%can){
  if(%client.player.getmountedimage(0)==fillcanimage.getid())
   %remount=1;
  parent::servercmdusefxcan(%client,%can);
  if(%remount)
   %client.player.mountimage(fillcanimage,0);
  %client.currentFXcan=%can+1;
 }
 function servercmdusespraycan(%client,%can){
  if(%client.player.getmountedimage(0)==fillcanimage.getid())
   %remount=1;
  parent::servercmdusespraycan(%client,%can);
  if(%remount)
   %client.player.mountimage(fillcanimage,0);
  %client.currentFXcan=0;
 }
 function gameconnection::onclientleavegame(%client){
  for(%x=%client.undostack.tail;%x<%client.undostack.head;%x++){
   %t=%client.undostack.val[%x];
   if(getword(%t,1)$="FILLPAINT")
    getword(%t,0).delete();
  }
  parent::onclientleavegame(%client);
 }
};
activatepackage(fillcan);

function round(%a){
 %a+=0.5;
 if(%a>0)
  return(%a-((%a*1000000 % 1000000)/1000000));
 else
  return(%a+((%a*-1000000 % 1000000)/1000000)-1);
}