//HORIZONTAL

datablock fxDTSBrickData (brickPoleDiag_1x1fHorDiagData)
{
	brickFile = "./1x1f_horiz_diag.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "1x1f Horiz. Diag.";
	iconName = "Add-Ons/Brick_PoleDiagonals/1x1f_horiz_diag";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/1x1f_horiz_diag.dts";
};

datablock fxDTSBrickData (brickPoleDiag_2x2fHorDiagData)
{
	brickFile = "./2x2f_horiz_diag.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "2x2f Horiz. Diag.";
	iconName = "Add-Ons/Brick_PoleDiagonals/2x2f_horiz_diag";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/2x2f_horiz_diag.dts";
};

datablock fxDTSBrickData (brickPoleDiag_3x3fHorDiagData)
{
	brickFile = "./3x3f_horiz_diag.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "3x3f Horiz. Diag.";
	iconName = "Add-Ons/Brick_PoleDiagonals/3x3f_horiz_diag";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/3x3f_horiz_diag.dts";
};

datablock fxDTSBrickData (brickPoleDiag_4x4fHorDiagData)
{
	brickFile = "./4x4f_horiz_diag.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "4x4f Horiz. Diag.";
	iconName = "Add-Ons/Brick_PoleDiagonals/4x4f_horiz_diag";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/4x4f_horiz_diag.dts";
};

datablock fxDTSBrickData (brickPoleDiag_6x6fHorDiagData)
{
	brickFile = "./6x6f_horiz_diag.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "6x6f Horiz. Diag.";
	iconName = "Add-Ons/Brick_PoleDiagonals/6x6f_horiz_diag";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/6x6f_horiz_diag.dts";
};

//VERTICAL BOTTOM

datablock fxDTSBrickData (brickPoleDiag_1x1VertDiagAData)
{
	brickFile = "./1x1_vert_diagA.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "1x1 Vert. Diag. A";
	iconName = "Add-Ons/Brick_PoleDiagonals/1x1_vert_diagA";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/1x1_vert_diagA.dts";
};

datablock fxDTSBrickData (brickPoleDiag_2x2VertDiagAData)
{
	brickFile = "./2x2_vert_diagA.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "2x2 Vert. Diag. A";
	iconName = "Add-Ons/Brick_PoleDiagonals/2x2_vert_diagA";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/2x2_vert_diagA.dts";
};


datablock fxDTSBrickData (brickPoleDiag_3x3VertDiagAData)
{
	brickFile = "./3x3_vert_diagA.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "3x3 Vert. Diag. A";
	iconName = "Add-Ons/Brick_PoleDiagonals/3x3_vert_diagA";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/3x3_vert_diagA.dts";
};


datablock fxDTSBrickData (brickPoleDiag_4x4VertDiagAData)
{
	brickFile = "./4x4_vert_diagA.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "4x4 Vert. Diag. A";
	iconName = "Add-Ons/Brick_PoleDiagonals/4x4_vert_diagA";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/4x4_vert_diagA.dts";
};


datablock fxDTSBrickData (brickPoleDiag_5x5VertDiagAData)
{
	brickFile = "./5x5_vert_diagA.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "5x5 Vert. Diag. A";
	iconName = "Add-Ons/Brick_PoleDiagonals/5x5_vert_diagA";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/5x5_vert_diagA.dts";
};


datablock fxDTSBrickData (brickPoleDiag_6x6VertDiagAData)
{
	brickFile = "./6x6_vert_diagA.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "6x6 Vert. Diag. A";
	iconName = "Add-Ons/Brick_PoleDiagonals/6x6_vert_diagA";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/6x6_vert_diagA.dts";
};

//VERTICAL TOP

datablock fxDTSBrickData (brickPoleDiag_1x1VertDiagBData)
{
	brickFile = "./1x1_vert_diagB.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "1x1 Vert. Diag. B";
	iconName = "Add-Ons/Brick_PoleDiagonals/1x1_vert_diagB";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/1x1_vert_diagB.dts";
};

datablock fxDTSBrickData (brickPoleDiag_2x2VertDiagBData)
{
	brickFile = "./2x2_vert_diagB.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "2x2 Vert. Diag. B";
	iconName = "Add-Ons/Brick_PoleDiagonals/2x2_vert_diagB";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/2x2_vert_diagB.dts";
};


datablock fxDTSBrickData (brickPoleDiag_3x3VertDiagBData)
{
	brickFile = "./3x3_vert_diagB.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "3x3 Vert. Diag. B";
	iconName = "Add-Ons/Brick_PoleDiagonals/3x3_vert_diagB";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/3x3_vert_diagB.dts";
};


datablock fxDTSBrickData (brickPoleDiag_4x4VertDiagBData)
{
	brickFile = "./4x4_vert_diagB.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "4x4 Vert. Diag. B";
	iconName = "Add-Ons/Brick_PoleDiagonals/4x4_vert_diagB";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/4x4_vert_diagB.dts";
};


datablock fxDTSBrickData (brickPoleDiag_5x5VertDiagBData)
{
	brickFile = "./5x5_vert_diagB.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "5x5 Vert. Diag. B";
	iconName = "Add-Ons/Brick_PoleDiagonals/5x5_vert_diagB";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/5x5_vert_diagB.dts";
};


datablock fxDTSBrickData (brickPoleDiag_6x6VertDiagBData)
{
	brickFile = "./6x6_vert_diagB.blb";
	category = "Rounds";
	subCategory = "Diag. Poles";
	uiName = "6x6 Vert. Diag. B";
	iconName = "Add-Ons/Brick_PoleDiagonals/6x6_vert_diagB";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/6x6_vert_diagB.dts";
};
//HORIZONTAL 

datablock fxDTSBrickData (brickPoleDiag_1x1fHorDiagcollideNOData)
{
	brickFile = "./1x1f_horiz_diag.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles";
	uiName = "[N] 1x1f Horiz. Diag.";
	iconName = "Add-Ons/Brick_PoleDiagonals/1x1f_horiz_diagNO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/1x1f_horiz_diag.dts";
	isWaterBrick = true;
};

datablock fxDTSBrickData (brickPoleDiagcollide_2x2fHorDiagcollideNOData)
{
	brickFile = "./2x2f_horiz_diag.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles";
	uiName = "[N] 2x2f Horiz. Diag. ";
	iconName = "Add-Ons/Brick_PoleDiagonals/2x2f_horiz_diagNO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/2x2f_horiz_diag.dts";
	isWaterBrick = true;
};

datablock fxDTSBrickData (brickPoleDiagcollide_3x3fHorDiagcollideNOData)
{
	brickFile = "./3x3f_horiz_diag.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 3x3f Horiz. Diag. ";
	iconName = "Add-Ons/Brick_PoleDiagonals/3x3f_horiz_diagNO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/3x3f_horiz_diag.dts";
	isWaterBrick = true;
};

datablock fxDTSBrickData (brickPoleDiagcollide_4x4fHorDiagcollideNOData)
{
	brickFile = "./4x4f_horiz_diag.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 4x4f Horiz. Diag. ";
	iconName = "Add-Ons/Brick_PoleDiagonals/4x4f_horiz_diagNO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/4x4f_horiz_diag.dts";
	isWaterBrick = true;
};

datablock fxDTSBrickData (brickPoleDiagcollide_6x6fHorDiagcollideNOData)
{
	brickFile = "./6x6f_horiz_diag.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 6x6f Horiz. Diag. ";
	iconName = "Add-Ons/Brick_PoleDiagonals/6x6f_horiz_diagNO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/6x6f_horiz_diag.dts";
	isWaterBrick = true;
};

//VERTICAL BOTTOM

datablock fxDTSBrickData (brickPoleDiagcollide_1x1VertDiagAcollideNOData)
{
	brickFile = "./1x1_vert_diagA.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 1x1 Vert. Diag. A ";
	iconName = "Add-Ons/Brick_PoleDiagonals/1x1_vert_diagANO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/1x1_vert_diagA.dts";
	isWaterBrick = true;
};

datablock fxDTSBrickData (brickPoleDiagcollide_2x2VertDiagAcollideNOData)
{
	brickFile = "./2x2_vert_diagA.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 2x2 Vert. Diag. A ";
	iconName = "Add-Ons/Brick_PoleDiagonals/2x2_vert_diagANO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/2x2_vert_diagA.dts";
	isWaterBrick = true;
};


datablock fxDTSBrickData (brickPoleDiagcollide_3x3VertDiagAcollideNOData)
{
	brickFile = "./3x3_vert_diagA.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 3x3 Vert. Diag. A ";
	iconName = "Add-Ons/Brick_PoleDiagonals/3x3_vert_diagANO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/3x3_vert_diagA.dts";
	isWaterBrick = true;
};


datablock fxDTSBrickData (brickPoleDiagcollide_4x4VertDiagAcollideNOData)
{
	brickFile = "./4x4_vert_diagA.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 4x4 Vert. Diag. A ";
	iconName = "Add-Ons/Brick_PoleDiagonals/4x4_vert_diagANO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/4x4_vert_diagA.dts";
	isWaterBrick = true;
};


datablock fxDTSBrickData (brickPoleDiagcollide_5x5VertDiagAcollideNOData)
{
	brickFile = "./5x5_vert_diagA.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 5x5 Vert. Diag. A ";
	iconName = "Add-Ons/Brick_PoleDiagonals/5x5_vert_diagANO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/5x5_vert_diagA.dts";
	isWaterBrick = true;
};


datablock fxDTSBrickData (brickPoleDiagcollide_6x6VertDiagAcollideNOData)
{
	brickFile = "./6x6_vert_diagA.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 6x6 Vert. Diag. A ";
	iconName = "Add-Ons/Brick_PoleDiagonals/6x6_vert_diagANO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/6x6_vert_diagA.dts";
	isWaterBrick = true;
};

//VERTICAL TOP

datablock fxDTSBrickData (brickPoleDiagcollide_1x1VertDiagBcollideNOData)
{
	brickFile = "./1x1_vert_diagB.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 1x1 Vert. Diag. B ";
	iconName = "Add-Ons/Brick_PoleDiagonals/1x1_vert_diagBNO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/1x1_vert_diagB.dts";
	isWaterBrick = true;
};

datablock fxDTSBrickData (brickPoleDiagcollide_2x2VertDiagBcollideNOData)
{
	brickFile = "./2x2_vert_diagB.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 2x2 Vert. Diag. B ";
	iconName = "Add-Ons/Brick_PoleDiagonals/2x2_vert_diagBNO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/2x2_vert_diagB.dts";
	isWaterBrick = true;
};


datablock fxDTSBrickData (brickPoleDiagcollide_3x3VertDiagBcollideNOData)
{
	brickFile = "./3x3_vert_diagB.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 3x3 Vert. Diag. B ";
	iconName = "Add-Ons/Brick_PoleDiagonals/3x3_vert_diagBNO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/3x3_vert_diagB.dts";
	isWaterBrick = true;
};


datablock fxDTSBrickData (brickPoleDiagcollide_4x4VertDiagBcollideNOData)
{
	brickFile = "./4x4_vert_diagB.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 4x4 Vert. Diag. B ";
	iconName = "Add-Ons/Brick_PoleDiagonals/4x4_vert_diagBNO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/4x4_vert_diagB.dts";
	isWaterBrick = true;
};


datablock fxDTSBrickData (brickPoleDiagcollide_5x5VertDiagBcollideNOData)
{
	brickFile = "./5x5_vert_diagB.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 5x5 Vert. Diag. B ";
	iconName = "Add-Ons/Brick_PoleDiagonals/5x5_vert_diagBNO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/5x5_vert_diagB.dts";
	isWaterBrick = true;
};


datablock fxDTSBrickData (brickPoleDiagcollide_6x6VertDiagBcollideNOData)
{
	brickFile = "./6x6_vert_diagB.blb";
	category = "No-Collide";
	subCategory = "Diag. Poles ";
	uiName = "[N] 6x6 Vert. Diag. B ";
	iconName = "Add-Ons/Brick_PoleDiagonals/6x6_vert_diagBNO";
	hasPrint = 0;
	CollisionShapeName = "Add-Ons/Brick_PoleDiagonals/6x6_vert_diagB.dts";
	isWaterBrick = true;
};