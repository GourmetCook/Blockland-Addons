datablock fxDTSBrickData(brickminilargeogreplainData)
{
	brickFile = "./largeogreplain.blb";
	category = "Mini-Empires";
	subCategory = "DnD Expansion";
	uiName = "Large Ogre (Plain 1)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_largeogreplain";
};
datablock fxDTSBrickData(brickminilargeogreclubData)
{
	brickFile = "./largeogreclub.blb";
	category = "Mini-Empires";
	subCategory = "DnD Expansion";
	uiName = "Large Ogre (Club 1)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_largeogreclub";
};
datablock fxDTSBrickData(brickminismallogreplainData)
{
	brickFile = "./smallogreplain.blb";
	category = "Mini-Empires";
	subCategory = "DnD Expansion";
	uiName = "Small Ogre (Plain 1)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_smallogreplain";
};
datablock fxDTSBrickData(brickminismallogreclubData)
{
	brickFile = "./smallogreclub.blb";
	category = "Mini-Empires";
	subCategory = "DnD Expansion";
	uiName = "Small Ogre (Club 1)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_smallogreclub";
};
datablock fxDTSBrickData(brickminismalloaktreeData)
{
	brickFile = "./smalloaktree.blb";
	category = "Mini-Empires";
	subCategory = "DnD Expansion";
	uiName = "Small Oak Tree";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_smalloaktree";
};
datablock fxDTSBrickData(brickminimedoaktreeData)
{
	brickFile = "./medoaktree.blb";
	category = "Mini-Empires";
	subCategory = "DnD Expansion";
	uiName = "Medium Oak Tree";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_smalloaktree";
};
datablock fxDTSBrickData(brickminiemptyshelfData)
{
	brickFile = "./emptyshelf.blb";
	category = "Mini-Empires";
	subCategory = "DnD Expansion";
	uiName = "Shelf (Empty)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_emptyshelf";
};
datablock fxDTSBrickData(brickministockedshelfData)
{
	brickFile = "./shelfstocked.blb";
	category = "Mini-Empires";
	subCategory = "DnD Expansion";
	uiName = "Shelf (Stocked)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_stockedshelf";
};
datablock fxDTSBrickData(brickminimarketstall1Data)
{
	brickFile = "./marketstall1.blb";
	category = "Mini-Empires";
	subCategory = "DnD Expansion";
	uiName = "Market Stall (x1)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_marketstallx1";
};
datablock fxDTSBrickData(brickminimarketstall2Data)
{
	brickFile = "./marketstall2.blb";
	category = "Mini-Empires";
	subCategory = "DnD Expansion";
	uiName = "Market Stall (x2)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_marketstallx2";
};
datablock fxDTSBrickData(brickminislime2x2Data)
{
	brickFile = "./slime.blb";
	category = "Mini-Empires";
	subCategory = "DnD Expansion";
	uiName = "Slime (2x2x4f)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_slime";
};

datablock fxDTSBrickData(brick1Forthx1FCenteredData)
{
	brickFile = "./1Forthx1F Centered.blb";
	category = "Plates";
	subCategory = "0.25x";
	uiName = "0.25x1F Centered";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.25x1fcentered";
};

datablock fxDTSBrickData(brick1Halfx1FCenteredData)
{
	brickFile = "./1Halfx1F Centered.blb";
	category = "Plates";
	subCategory = "0.5x";
	uiName = "0.50x1F Centered";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.5x1fcentered";
};

datablock fxDTSBrickData(brick3Forthx1FCenteredData)
{
	brickFile = "./3Forthx1F Centered.blb";
	category = "Plates";
	subCategory = "0.75x";
	uiName = "0.75x1F Centered";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.75x1fcentered";
};

datablock fxDTSBrickData(brick1ForthxFCenteredData)
{
	brickFile = "./1ForthxF Centered.blb";
	category = "Plates";
	subCategory = "0.25x";
	uiName = "0.25x0.25F Centered";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.25x0.25fcentered";
};

datablock fxDTSBrickData(brick1HalfxFCenteredData)
{
	brickFile = "./1HalfxF Centered.blb";
	category = "Plates";
	subCategory = "0.5x";
	uiName = "0.5x0.5F Centered";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.5x0.5fcentered";
};

datablock fxDTSBrickData(brick3ForthxFCenteredData)
{
	brickFile = "./3ForthxF Centered.blb";
	category = "Plates";
	subCategory = "0.75x";
	uiName = "0.75x0.75F Centered";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.75x0.75fcentered";
};

datablock fxDTSBrickData(brick1Forthx1FRampData)
{
	brickFile = "./1Forthx1F Ramp.blb";
	category = "Plates";
	subCategory = "0.25x";
	uiName = "0.25x1F Ramp";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.25x1framp";
};

datablock fxDTSBrickData(brick1Halfx1FRampData)
{
	brickFile = "./1Halfx1F Ramp.blb";
	category = "Plates";
	subCategory = "0.5x";
	uiName = "0.50x1F Ramp";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.5x1framp";
};

datablock fxDTSBrickData(brick3Forthx1FRampData)
{
	brickFile = "./3Forthx1F Ramp.blb";
	category = "Plates";
	subCategory = "0.75x";
	uiName = "0.75x1F Ramp";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.75x1framp";
};

datablock fxDTSBrickData (brick18x18data)
{
   brickFile = "./18x18.blb";
   category = "Baseplates";
   subCategory = "Tabletops";
   uiName = "18x18";
   iconName = "Add-Ons/Brick_DnDExpansionPack/18x18";
};

datablock fxDTSBrickData (brick26x26data)
{
   brickFile = "./26x26.blb";
   category = "Baseplates";
   subCategory = "Tabletops";
   uiName = "26x26";
   iconName = "Add-Ons/Brick_DnDExpansionPack/26x26";
};


//NOCOLLIDES


datablock fxDTSBrickData(brickminismalloaktreeNOData)
{
	brickFile = "./smalloaktree.blb";
	category = "No-Collide";
	subCategory = "DnD Expansion";
	uiName = "[N] Small Oak Tree";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_smalloaktreeNO";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brickminimedoaktreeNOData)
{
	brickFile = "./minilargeoaktree.blb";
	category = "No-Collide";
	subCategory = "DnD Expansion";
	uiName = "[N] Medium Oak Tree";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_minilargeoaktreeNO";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brickminiemptyshelfNOData)
{
	brickFile = "./emptyshelf.blb";
	category = "No-Collide";
	subCategory = "DnD Expansion";
	uiName = "[N] Shelf (Empty)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_emptyshelfNO";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brickministockedshelfNOData)
{
	brickFile = "./shelfstocked.blb";
	category = "No-Collide";
	subCategory = "DnD Expansion";
	uiName = "[N] Shelf (Stocked)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_stockedshelfNO";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brickminimarketstall1NOData)
{
	brickFile = "./marketstall1.blb";
	category = "No-Collide";
	subCategory = "DnD Expansion";
	uiName = "[N] Market Stall (x1)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_marketstallx1NO";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brickminimarketstall2NOData)
{
	brickFile = "./marketstall2.blb";
	category = "No-Collide";
	subCategory = "DnD Expansion";
	uiName = "[N] Market Stall (x2)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_marketstallx2NO";
	isWaterBrick = true;
};
datablock fxDTSBrickData(brickminislime2x2NOData)
{
	brickFile = "./slime.blb";
	category = "No-Collide";
	subCategory = "DnD Expansion";
	uiName = "[N] Slime (2x2x4f)";
	iconName = "Add-Ons/Brick_DnDExpansionPack/icon_slimeNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1Forthx1FCenteredNOData)
{
	brickFile = "./1Forthx1F Centered.blb";
	category = "No-Collide";
	subCategory = "0.25x";
	uiName = "[N] 0.25x1F Centered";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.25x1fcenteredNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1Halfx1FCenteredNOData)
{
	brickFile = "./1Halfx1F Centered.blb";
	category = "No-Collide";
	subCategory = "0.5x";
	uiName = "[N] 0.50x1F Centered";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.5x1fcenteredNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick3Forthx1FCenteredNOData)
{
	brickFile = "./3Forthx1F Centered.blb";
	category = "No-Collide";
	subCategory = "0.75x";
	uiName = "[N] 0.75x1F Centered";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.75x1fcenteredNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1ForthxFCenteredNOData)
{
	brickFile = "./1ForthxF Centered.blb";
	category = "No-Collide";
	subCategory = "0.25x";
	uiName = "[N] 0.25x0.25F Centered";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.25x0.25fcenteredNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1HalfxFCenteredNOData)
{
	brickFile = "./1HalfxF Centered.blb";
	category = "No-Collide";
	subCategory = "0.5x";
	uiName = "[N] 0.5x0.5F Centered";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.5x0.5fcenteredNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick3ForthxFCenteredNOData)
{
	brickFile = "./3ForthxF Centered.blb";
	category = "No-Collide";
	subCategory = "0.75x";
	uiName = "[N] 0.75x0.75F Centered";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.75x0.75fcenteredNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1Forthx1FRampNOData)
{
	brickFile = "./1Forthx1F Ramp.blb";
	category = "No-Collide";
	subCategory = "0.25x";
	uiName = "[N] 0.25x1F Ramp";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.25x1frampNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1Halfx1FRampNOData)
{
	brickFile = "./1Halfx1F Ramp.blb";
	category = "No-Collide";
	subCategory = "0.5x";
	uiName = "[N] 0.50x1F Ramp";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.5x1frampNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick3Forthx1FRampNOData)
{
	brickFile = "./3Forthx1F Ramp.blb";
	category = "No-Collide";
	subCategory = "0.75x";
	uiName = "[N] 0.75x1F Ramp";
	iconName = "Add-Ons/Brick_DnDExpansionPack/0.75x1frampNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData (brick18x18NOdata)
{
   brickFile = "./18x18.blb";
   category = "No-Collide";
   subCategory = "Tabletops";
   uiName = "[N] 18x18";
   iconName = "Add-Ons/Brick_DnDExpansionPack/18x18NO";
   isWaterBrick = true;
};

datablock fxDTSBrickData (brick26x26NOdata)
{
   brickFile = "./26x26.blb";
   category = "No-Collide";
   subCategory = "Tabletops";
   uiName = "[N] 26x26";
   iconName = "Add-Ons/Brick_DnDExpansionPack/26x26NO";
   isWaterBrick = true;
};