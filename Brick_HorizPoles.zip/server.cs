datablock fxDTSBrickData(brick1x1fHorizPoleData)
{
	brickFile = "./1x1FHorizPole.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x1f Horizontal pole";
	iconName = "Add-ons/Brick_HorizPoles/1x1HorizPole";
};

datablock fxDTSBrickData(brick1x2fHorizPoleData)
{
	brickFile = "./1x2FHorizPole.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x2f Horizontal pole";
	iconName = "Add-ons/Brick_HorizPoles/1x2HorizPole";
};

datablock fxDTSBrickData(brick1x3fHorizPoleData)
{
	brickFile = "./1x3FHorizPole.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x3f Horizontal pole";
	iconName = "Add-ons/Brick_HorizPoles/1x3HorizPole";
};

datablock fxDTSBrickData(brick1x4fHorizPoleData)
{
	brickFile = "./1x4FHorizPole.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x4f Horizontal pole";
	iconName = "Add-ons/Brick_HorizPoles/1x4HorizPole";
};

datablock fxDTSBrickData(brick1x6fHorizPoleData)
{
	brickFile = "./1x6FHorizPole.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x6f Horizontal pole";
	iconName = "Add-ons/Brick_HorizPoles/1x6HorizPole";
};

datablock fxDTSBrickData(brick1x8fHorizPoleData)
{
	brickFile = "./1x8FHorizPole.blb";
	category = "Rounds";
	subCategory = "Poles";
	uiName = "1x8f Horizontal pole";
	iconName = "Add-ons/Brick_HorizPoles/1x8HorizPole";
};


//NOCOLLIDES


datablock fxDTSBrickData(brick1x1fHorizPoleNOData)
{
	brickFile = "./1x1FHorizPole.blb";
	category = "No-Collide";
	subCategory = "Poles";
	uiName = "1x1f Horizontal pole";
	iconName = "Add-ons/Brick_HorizPoles/1x1HorizPoleNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1x2fHorizPoleNOData)
{
	brickFile = "./1x2FHorizPole.blb";
	category = "No-Collide";
	subCategory = "Poles";
	uiName = "1x2f Horizontal pole";
	iconName = "Add-ons/Brick_HorizPoles/1x2HorizPoleNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1x3fHorizPoleNOData)
{
	brickFile = "./1x3FHorizPole.blb";
	category = "No-Collide";
	subCategory = "Poles";
	uiName = "1x3f Horizontal pole";
	iconName = "Add-ons/Brick_HorizPoles/1x3HorizPoleNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1x4fHorizPoleNOData)
{
	brickFile = "./1x4FHorizPole.blb";
	category = "No-Collide";
	subCategory = "Poles";
	uiName = "1x4f Horizontal pole";
	iconName = "Add-ons/Brick_HorizPoles/1x4HorizPoleNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1x6fHorizPoleNOData)
{
	brickFile = "./1x6FHorizPole.blb";
	category = "No-Collide";
	subCategory = "Poles";
	uiName = "1x6f Horizontal pole";
	iconName = "Add-ons/Brick_HorizPoles/1x6HorizPoleNO";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick1x8fHorizPoleNOData)
{
	brickFile = "./1x8FHorizPole.blb";
	category = "No-Collide";
	subCategory = "Poles";
	uiName = "1x8f Horizontal pole";
	iconName = "Add-ons/Brick_HorizPoles/1x8HorizPoleNO";
	isWaterBrick = true;
};