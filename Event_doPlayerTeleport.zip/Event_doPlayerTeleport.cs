function fxDTSBrick::doPlayerTeleport(%obj,%target,%dir,%velocityop,%rel,%client)
{
    //we need to find the specified Named Brick.
    //get nt object array stuff
    %group = %obj.getGroup();
    %targetobj = %group.NTObject_[%target,0];
    
    // re-adding functionality for teleporting to the brick you click (with relays, etc)
    if(%target $= "SELF") {
        %targetObj = %obj;
    }
    
    if(!isObject(%targetobj)) {
        return;
    }
    
    // teleport
    if(isobject(%client.player))
    {
        %player = %client.player;
        switch (%dir)
        {	
            case 0 :
            %prot = getwords(%player.gettransform(),3,6);

            case 1 :
            %prot = "1 0 0 0";
            %velo = 0;

            case 2 :
            %prot = "0 0 1 1.57079";
            %velo = 1;

            case 3 :
            %prot = "0 0 1 3.14159";
            %velo = 2;

            case 4 :
            %prot = "0 0 1 -1.57079";
            %velo = 3;

            
        }
        if(%rel != 1)
        {
            %or = getwords(%targetobj.gettransform(),0,2);
            %lscale = 0.1*%targetobj.getdatablock().bricksizez;

            %finalsend = "0 0" SPC %lscale;
            %fr = vectoradd(%or,%finalsend);

            
            %finaltransform =  %fr SPC %prot;
            %turn = %player.getvelocity();
            %player.settransform(%finaltransform);
        }
        if(%rel == 1)
        {
            %or = getwords(%targetobj.gettransform(),0,2);
            %lscale = 0.1*%targetobj.getdatablock().bricksizez;
            %finalsend = "0 0" SPC %lscale;

            %offset = vectorsub(%player.getposition(),%obj.getposition());
            %player.settransform(vectoradd(%targetobj.getposition(),%offset) SPC getwords(%player.gettransform(),3,6));
        }
        if(%velocityop == 0)
        {
            %player.setvelocity("0 0 0");
        }
    }
}

registerOutputEvent("fxDTSBrick","doPlayerTeleport","string 500 90\tlist Relative 0 North 1 East 2 South 3 West 4\tbool\tbool",1);