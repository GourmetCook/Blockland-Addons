datablock fxDTSBrickData(brick05xCenteredData)
{
	brickFile = "./0.5xCentered.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Centered";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xCentered";
};

datablock fxDTSBrickData(brick05xCenteredTurnData)
{
	brickFile = "./0.5xCentered_Turn.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Cent. Turn";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xCentered_Turn";
};

datablock fxDTSBrickData(brick05xCenteredTData)
{
	brickFile = "./0.5xCentered_T.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Cent. T";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xCentered_T";
};

datablock fxDTSBrickData(brick05xCenteredCrossData)
{
	brickFile = "./0.5xCentered_Cross.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Cent. Cross";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xCentered_Cross";
};

datablock fxDTSBrickData(brick05xCenteredShortEndData)
{
	brickFile = "./0.5xCentered_End_Short.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Cent. End Short";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xCentered_End_Short";
};

datablock fxDTSBrickData(brick05xCenteredLongEndData)
{
	brickFile = "./0.5xCentered_End_Long.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Cent. End Long";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xCentered_End_Long";
};



datablock fxDTSBrickData(brick05xCenteredStraightData)
{
	brickFile = "./0.5xCentered_Straight.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Cent. Straight";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xCentered_Straight";
};

datablock fxDTSBrickData(brick05xCenteredLTAdapData)
{
	brickFile = "./0.5xCentered_L_Turn_Adapter.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Cent. LTurn Adapter";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xCentered_L_Turn_Adapter";
};

datablock fxDTSBrickData(brick05xCenteredRTAdapData)
{
	brickFile = "./0.5xCentered_R_Turn_Adapter.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Cent. RTurn Adapter";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xCentered_R_Turn_Adapter";
};

datablock fxDTSBrickData(brick05xCenteredRAdapData)
{
	brickFile = "./0.5xCentered_R_Adapter.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Cent. RAdapter";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xCentered_R_Adapter";
};

datablock fxDTSBrickData(brick05xCenteredLAdapData)
{
	brickFile = "./0.5xCentered_L_Adapter.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Cent. LAdapter";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xCentered_L_Adapter";
};




datablock fxDTSBrickData(brick05xNegativeCrossEdgeData)
{
	brickFile = "./0.5xNegative_Cross_Edge.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. Cross Edge";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_Cross_Edge";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeCenteredData)
{
	brickFile = "./0.5xNegative_Centered.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. Centered";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_Centered";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeTurnData)
{
	brickFile = "./0.5xNegative_Turn.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. Turn";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_Turn";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeTData)
{
	brickFile = "./0.5xNegative_T.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. T Full";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_T";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeCrossDiagData)
{
	brickFile = "./0.5xNegative_Cross_Diag.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. Cross Diag";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_Cross_Diag";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeCrossLData)
{
	brickFile = "./0.5xNegative_Cross_L.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. Cross L";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_Cross_L";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeCrossAllData)
{
	brickFile = "./0.5xNegative_Cross_All.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. Cross All";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_Cross_All";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeEndShortPartData)
{
	brickFile = "./0.5xNegative_End_ShortPart.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. End Short Part";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_End_ShortPart";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeEndShortFullData)
{
	brickFile = "./0.5xNegative_End_ShortFull.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. End Short Full";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_End_ShortFull";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeEndShortCapData)
{
	brickFile = "./0.5xCentered_End_Short.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. End Short Cap";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xCentered_End_Short";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeStraightData)
{
	brickFile = "./0.5xNegative_Straight.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. Straight";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_Straight";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeEndLongFullData)
{
	brickFile = "./0.5xNegative_End_LongFull.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. End Long Full";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_End_LongFull";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeEndLongCapData)
{
	brickFile = "./0.5xNegative_End_LongCap.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. End Long Cap";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_End_LongCap";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeLTurnAdapData)
{
	brickFile = "./0.5xNegative_L_Turn_Adapter.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. L_Turn Adapter";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_L_Turn_Adapter";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeRTurnAdapData)
{
	brickFile = "./0.5xNegative_R_Turn_Adapter.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. R Turn Adapter";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_R_Turn_Adapter";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeLAdapFullData)
{
	brickFile = "./0.5xNegative_L_AdapterFull.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. L Adapter Full";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_L_AdapterFull";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeRAdapFullData)
{
	brickFile = "./0.5xNegative_R_AdapterFull.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. R Adapter Full";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_R_AdapterFull";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeLAdapPartData)
{
	brickFile = "./0.5xNegative_L_AdapterPart.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. L Adapter Part";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_L_AdapterPart";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05xNegativeRAdapPartData)
{
	brickFile = "./0.5xNegative_R_AdapterPart.blb";
	category = "Plates";
	subCategory = "0.5x Centered";
	uiName = "0.5x Neg. R Adapter Part";
	iconName = "Add-Ons/Brick_SmallBricksExt05x/0.5xNegative_R_AdapterPart";
	isWaterBrick = true;
};