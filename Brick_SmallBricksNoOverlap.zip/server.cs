
datablock fxDTSBrickData(brick05x2PlateNoOverlapData)
{
	brickFile = "./0.5x2NoOverlap.blb";
	category = "Plates";
	subCategory = "0.5x No Overlap";
	uiName = "0.5x2 No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.5x2";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x2fPlateNoOverlapData)
{
	brickFile = "./0.5x2fNoOverlap.blb";
	category = "Plates";
	subCategory = "0.5x No Overlap";
	uiName = "0.5x2F No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.5x2f";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x1PlateNoOverlapData)
{
	brickFile = "./0.5x1NoOverlap.blb";
	category = "Plates";
	subCategory = "0.5x No Overlap";
	uiName = "0.5x1 No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.5x1";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x1fPlateNoOverlapData)
{
	brickFile = "./0.5x1fNoOverlap.blb";
	category = "Plates";
	subCategory = "0.5x No Overlap";
	uiName = "0.5x1F No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.5x1f";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x05EdgeNoOverlapData)
{
	brickFile = "./0.5x0.5EdgeNoOverlap.blb";
	category = "Plates";
	subCategory = "0.5x No Overlap";
	uiName = "0.5x0.5 Edge No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.5x0.5Edge";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x05fEdgeNoOverlapData)
{
	brickFile = "./0.5x0.5fEdgeNoOverlap.blb";
	category = "Plates";
	subCategory = "0.5x No Overlap";
	uiName = "0.5x0.5F No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.5x0.5fEdge";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x05CornerNoOverlapData)
{
	brickFile = "./0.5x0.5CornerNoOverlap.blb";
	category = "Plates";
	subCategory = "0.5x No Overlap";
	uiName = "0.5x0.5 Corner No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.5x0.5Corner";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick05x05fCornerNoOverlapData)
{
	brickFile = "./0.5x0.5fCornerNoOverlap.blb";
	category = "Plates";
	subCategory = "0.5x No Overlap";
	uiName = "0.5x0.5F Corner No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.5x0.5fCorner";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x2PlateNoOverlapData)
{
	brickFile = "./0.25x2NoOverlap.blb";
	category = "Plates";
	subCategory = "0.25x No Overlap";
	uiName = "0.25x2 No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.25x2";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x2fPlateNoOverlapData)
{
	brickFile = "./0.25x2fNoOverlap.blb";
	category = "Plates";
	subCategory = "0.25x No Overlap";
	uiName = "0.25x2F No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.25x2f";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x1PlateNoOverlapData)
{
	brickFile = "./0.25x1NoOverlap.blb";
	category = "Plates";
	subCategory = "0.25x No Overlap";
	uiName = "0.25x1 No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.25x1";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x1fPlateNoOverlapData)
{
	brickFile = "./0.25x1fNoOverlap.blb";
	category = "Plates";
	subCategory = "0.25x No Overlap";
	uiName = "0.25x1F No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.25x1f";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x025EdgeNoOverlapData)
{
	brickFile = "./0.25x0.25EdgeNoOverlap.blb";
	category = "Plates";
	subCategory = "0.25x No Overlap";
	uiName = "0.25x0.25 Edge No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.25x0.25Edge";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x025fEdgeNoOverlapData)
{
	brickFile = "./0.25x0.25fEdgeNoOverlap.blb";
	category = "Plates";
	subCategory = "0.25x No Overlap";
	uiName = "0.25x0.25F No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.25x0.25fEdge";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x025CornerNoOverlapData)
{
	brickFile = "./0.25x0.25CornerNoOverlap.blb";
	category = "Plates";
	subCategory = "0.25x No Overlap";
	uiName = "0.25x0.25 Corner No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.25x0.25Corner";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick025x025fCornerNoOverlapData)
{
	brickFile = "./0.25x0.25fCornerNoOverlap.blb";
	category = "Plates";
	subCategory = "0.25x No Overlap";
	uiName = "0.25x0.25F Corner No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.25x0.25fCorner";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x2PlateNoOverlapData)
{
	brickFile = "./0.75x2NoOverlap.blb";
	category = "Plates";
	subCategory = "0.75x No Overlap";
	uiName = "0.75x2 No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.75x2";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x2fPlateNoOverlapData)
{
	brickFile = "./0.75x2fNoOverlap.blb";
	category = "Plates";
	subCategory = "0.75x No Overlap";
	uiName = "0.75x2F No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.75x2f";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x1PlateNoOverlapData)
{
	brickFile = "./0.75x1NoOverlap.blb";
	category = "Plates";
	subCategory = "0.75x No Overlap";
	uiName = "0.75x1 No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.75x1";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x1fPlateNoOverlapData)
{
	brickFile = "./0.75x1fNoOverlap.blb";
	category = "Plates";
	subCategory = "0.75x No Overlap";
	uiName = "0.75x1F No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.75x1f";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x075EdgeNoOverlapData)
{
	brickFile = "./0.75x0.75EdgeNoOverlap.blb";
	category = "Plates";
	subCategory = "0.75x No Overlap";
	uiName = "0.75x0.75 Edge No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.75x0.75Edge";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x075fEdgeNoOverlapData)
{
	brickFile = "./0.75x0.75fEdgeNoOverlap.blb";
	category = "Plates";
	subCategory = "0.75x No Overlap";
	uiName = "0.75x0.75F No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.75x0.75fEdge";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x075CornerNoOverlapData)
{
	brickFile = "./0.75x0.75CornerNoOverlap.blb";
	category = "Plates";
	subCategory = "0.75x No Overlap";
	uiName = "0.75x0.75 Corner No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.75x0.75Corner";
	isWaterBrick = true;
};

datablock fxDTSBrickData(brick075x075fCornerNoOverlapData)
{
	brickFile = "./0.75x0.75fCornerNoOverlap.blb";
	category = "Plates";
	subCategory = "0.75x No Overlap";
	uiName = "0.75x0.75F Corner No Overlap";
	iconName = "Add-Ons/Brick_SmallBricksNoOverlap/0.75x0.75fCorner";
	isWaterBrick = true;
};
